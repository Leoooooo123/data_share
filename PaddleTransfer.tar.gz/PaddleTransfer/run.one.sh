
for((i=0;i<$2;i++));do
    python -u $1
done
