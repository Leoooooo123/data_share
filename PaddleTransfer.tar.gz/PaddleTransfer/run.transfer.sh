#ps axu |grep train_placeholder.py |sed 's/\s\+/ /g' |cut -d' ' -f2|xargs -i kill -9 {}

#mkdir -p log

gpu=(0 1)
i=0
for i in 0; do
#for m in resnet50 mobilenet_v2; do
for m in resnet50; do
for data in Stanford_Cars; do
#for data in dtd flower102 Oxford_Pet indoorCVPR_09 Medical_Shenzhen CUB_200_2011 Stanford_Cars; do
for bs in 16; do
for algo in cot; do
    #ckpt="$m.$data.bs$bs.$algo.r$i"
    param="finetune_cnn.py --name $data --batch_size $bs --batch_size_eval $bs --model_arch $m --train_dir ../../data/finetune/paddletransfer/$data/  --eval_dir ../../data/finetune/paddletransfer/$data/ --save_dir output --algo $algo --gpu ${gpu[i]}"
    k8s="local"
    if [ "$k8s" == "local" ]; then
        #nohup bash run.one.sh "$param" 3 &
        bash run.one.sh "$param" 1
        i=`expr $i + 1`
        if [ $i -eq 7 ]; then
            i=0
            wait
        fi
    fi
done
done
done
done
done
