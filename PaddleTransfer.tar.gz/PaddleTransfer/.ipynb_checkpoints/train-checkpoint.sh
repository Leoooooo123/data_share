gpu=(3 4 5 6 7)
i=0
for lr in 0.1 0.05 0.01 0.005 0.001; do
    nohup python finetune.py --name Stanford_Cars --train_dir ../../data/finetune/paddletransfer/Stanford_Cars/train --eval_dir ../../data/finetune/paddletransfer/Stanford_Cars/test --save ./lr_and_momentum --epochs 30 --momentum 0.99 --gpu ${gpu[i]} --eval_frequency 10 --algo base --lr $lr &
    i=`expr $i + 1`
done
