from matplotlib import pyplot as plt
import numpy as np
import os
import sys
import time
from sklearn.metrics.pairwise import euclidean_distances
import pyemd

# In this example on CUB-200, we demonstrate how to calculate feature and weight for each class.
feature_dir = './features/'
dataset = 'FGVC_Aircraft'

# Load extracted features on CUB-200.
feature = np.load(os.path.join(feature_dir, f'{dataset}_features.npy'))
label = np.load(os.path.join(feature_dir, f'{dataset}_labels.npy'))

# CUB-200 training set contains 5994 images from 200 classes, each image is 
# represented by a 2048-dimensional feature from the pre-trained ResNet-101.
print('Original feature shape: (%d, %d)' % (feature.shape[0], feature.shape[1]))
print('Number of classes: %d' % (len(np.unique(label))))

# Calculate class feature as the averaged features among all images of the class.
# Class weight is defined as the number of images of the class.
sorted_label = sorted(list(set(label)))
feature_per_class = np.zeros((len(sorted_label), 2048), dtype=np.float32)
weight = np.zeros((len(sorted_label), ), dtype=np.float32)
counter = 0
for i in sorted_label:
    idx = [(l==i) for l in label]
    feature_per_class[counter, :] = np.mean(feature[idx, :], axis=0)
    weight[counter] = np.sum(idx)
    counter += 1

print('Feature per class shape: (%d, %d)' % (feature_per_class.shape[0], 
                                             feature_per_class.shape[1]))

np.save(os.path.join(feature_dir, f'{dataset}.npy'), feature_per_class)
np.save(os.path.join(feature_dir, f'{dataset}_weight.npy'), weight)
# exit()

# Calculate domain similarity by Earth Mover's Distance (EMD).

# Set minimum number of images per class for computational efficiency.
# Classes in source domain with less than min_num_imgs images will be ignored.
min_num_imgs = 10

# Gamma for domain similarity: exp(-gamma x EMD)
gamma = 0.01

# Three source domain datasets: 
# ImageNet (ILSVRC 2012) training set,
# iNaturalist 2017 training set (original training + 90% validation), 
# ImageNet + iNaturalist training set.
source_domain = ['imagenet']

# Seven target domain datasets (all of them are from the training set):
# CUB-200-2011 Bird, Oxford Flower 102, Stanford Car, Stanford Dog, 
# FGVC-Aircraft, NABirds, Food 101
target_domain = ['CUB_200','FGVC_Aircraft','dtd','flowers102','indoorCVPR_09','Stanford_Cars']

# Create ImageNet + iNaturalist feature and weight by concatenation.

tic = time.time()
for sd in source_domain:
    for td in target_domain:
        print('%s --> %s' % (sd, td))
        f_s = np.load(os.path.join(feature_dir, f'{sd}.npy'))
        f_t = np.load(os.path.join(feature_dir, f'{td}.npy'))
        w_s = np.load(os.path.join(feature_dir, f'{sd}_weight.npy'))
        w_t = np.load(os.path.join(feature_dir, f'{td}_weight.npy'))

        # Remove source domain classes with number of images < 'min_num_imgs'.
        # idx = [i for i in range(len(w_s)) if w_s[i] >= min_num_imgs]
        # f_s = f_s[idx, :]
        # w_s = w_s[idx]

        # Make sure two histograms have the same length and distance matrix is square.
        data = np.float64(np.append(f_s, f_t, axis=0))
        w_1 = np.zeros((len(w_s) + len(w_t),), np.float64)
        w_2 = np.zeros((len(w_s) + len(w_t),), np.float64)
        w_1[:len(w_s)] = w_s / np.sum(w_s)
        w_2[len(w_s):] = w_t / np.sum(w_t)
        D = euclidean_distances(data, data)

        emd = pyemd.emd(np.float64(w_1), np.float64(w_2), np.float64(D))
        print('EMD: %.3f    Domain Similarity: %.3f\n' % (emd, np.exp(-gamma*emd)))
print('Elapsed time: %.3fs' % (time.time() - tic))