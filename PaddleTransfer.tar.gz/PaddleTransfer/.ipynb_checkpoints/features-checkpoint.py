import numpy as np
import paddle
from paddle.vision.datasets import DatasetFolder
from paddle.io import DataLoader
from paddle.vision import transforms
import argparse
from backbones import resnet50
import os
import tqdm

def get_dataloader(data_path):
    transform = transforms.Compose([
        transforms.Resize(size=(256, 256)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomCrop((224,224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
    dataset = DatasetFolder(data_path, transform=transform)
    dataloader = DataLoader(dataset, shuffle=False, batch_size=32)
    num_images = len(dataset)
    num_classes = len(dataset.classes)
    return dataloader, num_images, num_classes

if __name__ == "__main__":
    parser = argparse.ArgumentParser("feature extration")
    parser.add_argument("--name", type=str, default="")
    parser.add_argument("--data_path", type=str, default="")
    parser.add_argument("--save_path", type=str, default="./features/")
    args = parser.parse_args()
    dataloader, num_images, num_classes = get_dataloader(args.data_path)
    model = resnet50(pretrained=True,num_classes = num_classes)
    features=np.zeros((num_images,2048,7,7))
    labels = np.zeros(num_images)
    model.eval()
    for batch_id, data in enumerate(dataloader):
        image = data[0]
        label = data[1]
        _, feature = model(image)
        # feature = paddle.nn.AdaptiveAvgPool2D((1, 1))(feature).squeeze()
        features[batch_id*32:(batch_id+1)*32] = feature.numpy()
        labels[batch_id*32:(batch_id+1)*32] = label.numpy()
    print(features.shape)
    print(labels.shape)
    np.save(os.path.join(args.save_path,f"{args.name}_features.npy"), features)
    np.save(os.path.join(args.save_path,f"{args.name}_labels.npy"), labels)