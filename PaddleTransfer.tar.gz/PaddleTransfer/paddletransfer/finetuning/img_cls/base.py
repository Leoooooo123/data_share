import numpy as np
import paddle
import paddle.nn.functional as F

class FinetuneBase: 
    def __init__(self, model, model_arch, data_loader = None, vit_config = None, confs=None):
        self.model = model
        self.model_arch = model_arch

    def loss(self, x_data, y_data, logits, features, epoch, batch_id):
        return {}

    def params(self):
        if self.model_arch == "vit":
            parameters = [{'params': self.model.position_embedding},
                          {'params': self.model.cls_token},
                          {'params': self.model.patch_embedding.parameters()},
                          {'params': self.model.encoder.parameters()},
                          {'params': self.model.weight.parameters(), 'learning_rate':10.0},
                          {'params': self.model.classifier.parameters(), 'learning_rate':10.0}]
        else:
            parameters = [{'params': self.model.conv1.parameters()},
                        {'params': self.model.bn1.parameters()},
                        {'params': self.model.layer1.parameters()},
                        {'params': self.model.layer2.parameters()},
                        {'params': self.model.layer3.parameters()},
                        {'params': self.model.layer4.parameters()},
                        {'params': self.model.fc.parameters(), 'learning_rate':10.0}]
        return parameters
        # return self.model.parameters()
