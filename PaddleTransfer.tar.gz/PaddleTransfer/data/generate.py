import os
import argparse


def generate_list(path,ratio):
    assert os.path.isdir(path), f"{path} is not a dir"
    with open(f"{path}_list.txt", "a") as f:
        for i, sub_dir in enumerate(os.listdir(path)):
            sub_dir = os.path.join(path, sub_dir)
            assert os.path.isdir(sub_dir), f"{sub_dir} is not a dir"
            limit = int(ratio*len(os.listdir(sub_dir)))
            count = 0
            for img in os.listdir(sub_dir):
                if count>limit:
                    break
                count+=1
                file_path = os.path.join(sub_dir, img)
                f.write(f"{file_path} {i}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", default="train", type=str)
    parser.add_argument("--ratio",default=1.,type=float)
    args = parser.parse_args()
    generate_list(args.path,args.ratio)
