import os
import math
from paddle.io import Dataset
from paddle.io import DataLoader
from paddle.io import DistributedBatchSampler
from paddle.vision import transforms
from paddle.vision import image_load


class MyDataset(Dataset):
    """Build ImageNet2012 dataset

    This class gets train/val imagenet datasets, which loads transfomed data and labels.
    Note:
        train_list.txt and val_list.txt is required.
        Please refer https://github.com/BR-IDL/PaddleViT/image_classification#data-preparation

    Attributes:
        file_folder: path where imagenet images are stored
        transform: preprocessing ops to apply on image
        img_path_list: list of full path of images in whole dataset
        label_list: list of labels of whole dataset
    """

    def __init__(self, file_folder, is_train=True, transform_ops=None):
        """Init ImageNet2012 Dataset with dataset file path, mode(train/val), and transform"""
        super().__init__()
        self.file_folder = file_folder
        self.transforms = transform_ops
        self.img_path_list = []
        self.label_list = []

        list_name = 'train_list.txt' if is_train else 'val_list.txt'
        self.list_file = os.path.join(self.file_folder, list_name)
        assert os.path.isfile(self.list_file), f'{self.list_file} not exist!'

        with open(self.list_file, 'r') as infile:
            for line in infile:
                img_path = line.strip().split()[0]
                img_label = int(line.strip().split()[1])
                self.img_path_list.append(os.path.join(self.file_folder, img_path))
                self.label_list.append(img_label)
        # print(f'----- Imagenet2012 {list_name} len = {len(self.label_list)}')

    def __len__(self):
        return len(self.label_list)

    def __getitem__(self, index):
        data = image_load(self.img_path_list[index]).convert('RGB')
        data = self.transforms(data)
        label = self.label_list[index]

        return data, label

    @property
    def num_classes(self):
        return len(set(self.label_list))