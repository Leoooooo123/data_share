import numpy as np
import paddle
import paddle.nn.functional as F
from paddle import nn
from tqdm import tqdm
import torch
import os
from .base import FinetuneBase 


class VectorQuantizer(nn.Layer):
    def __init__(self, initialization, trade_off, beta=0.25, gamma = 0.01):
        super().__init__()
        self.K = initialization.shape[0]
        self.D = initialization.shape[1]
        self.beta = beta
        self.trade_off = trade_off
        # self.gamma = gamma

        # self.embedding = nn.Embedding(self.K, self.D)
        weight_attr_1 = paddle.framework.ParamAttr(
                initializer=paddle.nn.initializer.Assign(initialization))
        self.embedding = nn.Embedding(self.K, self.D, weight_attr = weight_attr_1)


    def forward(self, features):
        # features = features.transpose((0,2,3,1)) #paddle do not have method contiguous
        features_shape = features.shape
        flat_features = F.normalize(features.reshape([-1,self.D]))

        # reg_loss = paddle.norm(self.embedding.weight-self.initial_weight)
        dist = paddle.sum(flat_features ** 2, axis = 1, keepdim=True) + \
               paddle.sum(self.embedding.weight ** 2, axis = 1) - \
               2 * paddle.matmul(flat_features, self.embedding.weight.transpose((1,0)))

        # encoding_inds = paddle.argsort(dist, axis=1)
        # encoding_inds_1 = encoding_inds[:,0]
        # encoding_inds_2 = encoding_inds[:,1]
        # encoding_one_hot_1 = F.one_hot(encoding_inds_1, self.K)
        # encoding_one_hot_2 = F.one_hot(encoding_inds_2, self.K)

        # quantized_features_1 = paddle.matmul(encoding_one_hot_1, self.embedding.weight)
        # quantized_features_1 = quantized_features_1.reshape(features_shape)

        # quantized_features_2 = paddle.matmul(encoding_one_hot_2, self.embedding.weight)
        # quantized_features_2 = quantized_features_2.reshape(features_shape)

        # commitment_loss_1 = F.mse_loss(quantized_features_1.detach(), features)
        # commitment_loss_2 = F.mse_loss(quantized_features_2.detach(), features)
        # embedding_loss_1 = F.mse_loss(quantized_features_1, features.detach())
        # embedding_loss_2 = F.mse_loss(quantized_features_2.detach(), features)
        # commitment_loss = self.trade_off * commitment_loss_1 + (2.0-self.trade_off) * commitment_loss_2
        # embedding_loss = self.trade_off * embedding_loss_1 + (2.0-self.trade_off) * embedding_loss_2

        # vq_loss = commitment_loss_1 * self.beta + embedding_loss_1

        # quantized_features = features + (quantized_features_1-features).detach()

        # quantized_features = quantized_features.transpose((0,3,1,2))
        encoding_inds = paddle.argmax(dist, axis=1).unsqueeze(1)
        encoding_one_hot = F.one_hot(encoding_inds, self.K)

        quantized_features = paddle.matmul(encoding_one_hot, self.embedding.weight)
        quantized_features = quantized_features.reshape(features_shape)
        
        commitment_loss = F.mse_loss(quantized_features.detach(), features)
        embedding_loss = F.mse_loss(quantized_features, features.detach())
        vq_loss = commitment_loss * self.beta + embedding_loss

        return vq_loss, encoding_inds

class FinetuneQuant(FinetuneBase):
    _confs = {'reg_weight':2.0, 'init_path':'', 'trade_off':2.0, "embedding_ratio":0.01}
    def __init__(self, model, model_arch, data_loader = None, vit_config = None, confs=_confs):
        super(FinetuneQuant, self).__init__(model, model_arch = model_arch, confs = confs)
        self.reg_weight = float(confs['reg_weight'])
        self.trade_off = float(confs['trade_off'])
        self.init_path = confs['init_path']
        self.model = model
        self.model_arch = model_arch
        self.data_loader = data_loader
        self.initialization = self.quantization_initialization(confs['embedding_ratio'])

        self.initialization = F.normalize(paddle.to_tensor(self.initialization))

        if self.model_arch == "vit":
            self.quantizer = VectorQuantizer(self.initialization,self.trade_off)
        else:   
            self.quantizer = VectorQuantizer(self.initialization,self.trade_off)
    
    def quantization_initialization(self,embedding_ratio=0.1):
        init_path = self.init_path
        if os.path.exists(init_path):
            # return np.load(init_path)
            pass
        self.model.eval()
        with paddle.no_grad():
            for batch_id, data in enumerate(tqdm(self.data_loader)):
                image = data[0]
                label = data[1]
                _, feature = self.model(image)
                if batch_id == 0:
                    features = feature.numpy()
                    labels = label.numpy()
                else:
                    features = np.concatenate((features,feature.numpy()),0)
                    labels = np.concatenate((labels,label.numpy()),0)

        
        # inds = np.arange(features.shape[0])
        # choices = np.random.choice(inds,8192,replace=False)
        # candidates = features[choices]
        candidates = features

        # labels = labels.numpy()
        # print(features.shape)
        # print(labels.shape)

        # sorted_label = sorted(list(set(labels)))
        # candidates = np.zeros((len(sorted_label), 2048,7,7), dtype=np.float32)
        
        # counter = 0
        # for i in sorted_label:
        #     idx = [(l==i) for l in labels]
        #     candidates[counter, :] = np.mean(features[idx, :], axis=0)
        #     counter += 1
        print(f"-----embedding dim is {candidates.shape[-1]}")
        if self.model_arch == "vit":
            candidates = candidates.reshape((-1,candidates.shape[-1]))    
        else:
            candidates = candidates.transpose((0,2,3,1)).reshape((-1,candidates.shape[-1]))
        print(f'-----candidate shape: {candidates.shape}')

        # def kmeans_pp(X, K):
        #     X = torch.from_numpy(X).cuda()
        #     avg_norm = np.mean([torch.norm(X[i]).item() for i in range(X.shape[0])])
        #     mu = torch.zeros(1, X.shape[1]).cuda()
        #     indsAll = []
        #     while len(indsAll) < K:
        #         # print(len(indsAll))
        #         if len(indsAll) == 0:
        #             D2 = torch.cdist(X, mu).squeeze(1)
        #         else:
        #             newD = torch.cdist(X, mu[-1:])
        #             newD = torch.min(newD, dim = 1)[0]
        #             for i in range(X.shape[0]):
        #                 if D2[i] >  newD[i]:
        #                     D2[i] = newD[i]

        #         for i, ind in enumerate(D2.topk(1)[1]):
        #             D2[ind] = 0
        #             mu = torch.cat((mu, X[ind].unsqueeze(0)), 0)
        #             indsAll.append(ind)

        #     return [index.item() for index in indsAll]
        
        # print("---kmeans++ running, pls be patient---")
        # k means ++ initialization
        # indsAll = kmeans_pp(candidates.numpy(),512)
        # random initialization
        inds = np.arange(candidates.shape[0])
        if self.model_arch == "vit":
            indsAll = np.random.choice(inds,int(candidates.shape[0]*embedding_ratio),replace=False)
        else:
            indsAll = np.random.choice(inds,int(candidates.shape[0]*embedding_ratio),replace=False)
        # np.save("./visual/indeces.npy", indsAll)
        initialization = candidates[indsAll]
        # np.save("./visual/init.npy", initialization)
        print(f"-----initialization shape{initialization.shape}")
        return initialization

    def params(self):
        if self.model_arch == "vit":
            parameters = [{'params': self.model.position_embedding},
                          {'params': self.model.cls_token},
                          {'params': self.model.patch_embedding.parameters()},
                          {'params': self.model.encoder.parameters()},
                          {'params': self.model.classifier.parameters(), 'learning_rate':10.0},
                          {'params': self.quantizer.parameters()}]
        else:
            parameters = [{'params': self.model.conv1.parameters()},
                        {'params': self.model.bn1.parameters()},
                        {'params': self.model.layer1.parameters()},
                        {'params': self.model.layer2.parameters()},
                        {'params': self.model.layer3.parameters()},
                        {'params': self.model.layer4.parameters()},
                        {'params': self.model.fc.parameters(), 'learning_rate':10.0},
                        {'params': self.quantizer.parameters()}]
        return parameters
        # return [{'params':self.model.parameters()},
                # {'params':self.quantizer.parameters()}]
    
    def loss(self, x_data, y_data, logits, features, epoch, batch_id):
        self.quantizer.train()
        quantized_features, vq_loss, encoding_inds = self.quantizer(features)
        return {'vq_loss': self.reg_weight*vq_loss}, encoding_inds
