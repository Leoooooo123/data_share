# Quantization Transfer Learning Algorithm Usage
The quantization algorithm implementation is integreted into PaddleTransfer, the user can apply the algorithm both on cnn and transformer, the corresponding commands are as follows.

## To use quantization algorithm on CNN
```
python3 finetune_cnn.py --name [experiment_name] --train_dir [your_dataset_root_dir] --eval_dir [your_dataset_root_dir] --log_dir [path_for_saving_visual_log] --save_dir [path_for_saving_model_params_and_train_log] --algo quant
```
By using the default hyperparameter setting, the quant algorithm can achieve 40.42 accuracy on CUB_200_15% dataset, while the baseline is 39.23 on the same dataset with same hyperparameter setting.

## To use quantization algorithm on ViT
```
python3 finetune_vit.py --name [experiment_name] --train_dir [your_dataset_root_dir] --eval_dir [your_dataset_root_dir] --log_dir [path_for_saving_visual_log] --save_dir [path_for_saving_model_params_and_train_log] --algo quant --model_path [path_of_your_pretrained_vit_model]
```
You can download the pretrained model parameters on https://github.com/BR-IDL/PaddleViT.

By using the default hyperparameter setting, the quant algorithm can achieve 69.85 accuracy on CUB_200_15% dataset, while the baseline is 70.37 on the same dataset with same hyperparameter setting.

## Other Notifications
Please organize your dataset folder in the following way:
```
|_ root/
|  |_ train/
|  |_ train_list.txt
|  |_ val/
|  |_ val_list.txt
|  |_ test/
|  |_ test_list.txt

For train_list.txt and val_list.txt on CUB_200_15%, you can refer to the corresponding files in ./data, or the list files on github.com/thuml/Batch-Spectral-Shrinkage.

You can change the hyperparameters specified for the quantization algorithm for potential better performance, which are reg_weight(the weight of regularization loss) and num_embeddings(the size of codebook).


